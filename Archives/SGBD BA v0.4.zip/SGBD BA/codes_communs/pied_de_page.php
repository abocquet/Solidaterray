	<div id="pied_de_page">
		<p><strong>Cr�� par PrimProg, 2011</strong></p>
	</div>