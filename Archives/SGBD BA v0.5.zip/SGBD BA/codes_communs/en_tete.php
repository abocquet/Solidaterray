<div id="en_tete">
	<a href="index.php"><img class="imgblock" src="./images/header.png" title="Acceuil" /></a>
</div>
		
		