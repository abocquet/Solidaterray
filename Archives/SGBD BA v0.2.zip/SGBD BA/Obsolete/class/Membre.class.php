<?php

	class Membre {
		
		public $pseudo ;
		public $nom ;
		public $prenom ;
		public $passwd ;
		
		public function __construct($donnees)
		{
			$this->pseudo = $donnees['pseudo'] ;
			$this->passwd = $donnees['pass'] ;
			$this->nom = $donnees['nom'] ;
			$this->prenom = $donnees['prenom'] ;
			
			echo "Hello world" ;
		}
	}
?>