<?php

	class User {
		
		public $pseudo = 0 ;
		public $nom = 0;
		public $prenom = 0;
		public $passwd = 0 ;
		public $admin = 0 ;
		public $connecte = false ;
		
		public $bdd = NULL;
		public $req ;
		
		public function __construct()
		{
		
			try 
			{
				$this->bdd = new PDO('mysql:host=localhost;dbname=solidaterray', 'root', '');
			}
			catch (Exception $e) {
				die('Erreur : ' . $e->getMessage());
			}
			
			if((isset($_POST['login']) && isset($_POST['passwd'])) || (isset($_SESSION['login']) && isset($_SESSION['passwd'])))
			{
				if(!empty($_POST['login']) && !empty($_POST['passwd']))
				{
					$this->pseudo = $_POST['login'] ;
					$this->passwd = sha1($_POST['passwd']) ;
					
					$this->req = $this->bdd->prepare('SELECT * FROM membres WHERE pseudo = ? AND pass = ?') ;
					$this->req->execute(array($this->pseudo, $this->passwd)) ;
								$donnees = $this->req->fetch() ;

				}
				elseif (!empty($_SESSION['login']) && !empty($_SESSION['passwd']))
				{
					$this->req = $this->bdd->prepare('SELECT * FROM membres WHERE pseudo = ? AND pass = ?') ;
					$this->req->execute(array($_SESSION['login'], $_SESSION['passwd'])) ;
									$donnees = $this->req->fetch() ;

				}
				
				else
				{
					die ("erreur") ;
				}
				
				if($donnees)
				{
					
					$this->nom = $donnees['nom'] ;
					$this->prenom = $donnees['prenom'] ;
					$this->admin = $donnees['administrateur'] ;
						
					$this->connecte = TRUE ;
					
					
					
					
					if (!isset($_SESSION['login']) && !isset($_SESSION['passwd']))
					{
						session_start() ;
						$_SESSION['login'] = $this->pseudo ;
						$_SESSION['passwd'] = $this->passwd ;
					}
					
					echo "nihao" ;
				}
				else
				{
					echo "mauvais mdp" ;
					echo 'A<pre>';
					print_r($donnees) ;
					echo '</pre>B';
				}
				$this->req->closeCursor() ;
				
			}
			else
			{
				$this->nom = 0 ;
				$this->prenom = 0 ;
				$this->admin = 0 ;
				$this->passwd = 0 ;
				$this->pseudo = 0 ;
			}
			
			echo "$this->nom 
				$this->prenom 
				$this->admin 
				$this->passwd 
				$this->pseudo " ;
		}
		
		
		public function afficher()
		{	
			
		}
	
		public function afficherMenu()
		{
			if (!$this->connecte)
			{
			?>			
					
			<?php
			}
			
			else
			{
				echo 'Bonjour ' . $this->prenom ;
			}
		}
	}
	
?>