<?php
	
	class Administrateur extends Membre {
	
	}
?>