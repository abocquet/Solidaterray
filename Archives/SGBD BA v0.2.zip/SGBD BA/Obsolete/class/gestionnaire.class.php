<?php
	require ('Membre.class.php') ;
	require('Administrateur.class.php') ;
	
	class gestionnaire {
		
		public $bdd = NULL ;
		public $user = 0 ;
		
		public function __construct() {
		
			try {
				$this->bdd = new PDO('mysql:host=localhost;dbname=solidaterray', 'root', '');
			}
			catch (Exception $e) {
				die('Erreur : ' . $e->getMessage());
			}
			
		}
		
		public function instancier()
		{
			if ($_SESSION['user'] != 0)
			{
				this->creer();
			}
			else 
			{
				this->recuperer();
			}
		}
		
		private function creer()
		{
			if (isset($_POST['login']) && isset($_POST['passwd']) && !empty($_POST['login']) && !empty($_POST['passwd']))
			{
				$req = $bdd->prepare('SELECT * FROM membres WHERE pseudo = ? AND pass = ?') ;
				$req->execute(array($_POST['login'], sha1($_POST['passwd']))) ;
				
				if ($donnees = $req->fetch())
				{
					if ($donnees['administrateur'] == 1)
					{
						$user = new Administrateur($donnees) ;
					}
					else
					{
						$user = new Membre($donnees) ;
					}
				}
				else
				{
					header('Location: index.php');
				}
			}
		}
		
		private function recuperer()
		{
		
		}
		
		public function deposer()
		{
		
		}
		
		public function affiche($texte) 
		{
			
			if ($texte == 'CLASSEMENT')
			{
					if (isset($_GET['classement']) && !empty($_GET['classement']))
					{
						if (isset($_GET['classe']) && !empty($_GET['classe']))
						{
							if (isset($_GET['groupe']) && !empty($_GET['groupe']))
							{
								$req = $this->bdd->prepare('SELECT * FROM classe WHERE niveau = ? AND groupe = ?') ;
								$req->execute(array($_GET['classe'], $_GET['groupe'])) ;
								
								$donnees = $req->fetch() ;
								echo('<p>La classe de ' . $donnees['niveau'] . '<sup>�m</sup>' . $donnees['groupe'] . 'a appport� de la nouriture pour un poid
									total de ' . $donnees['poid'] . ' et ' . $donnees['point'] . ' points.</p>') ;
									
								$req->closeCursor() ;
								
								$req = $this->bdd->prepare('SELECT * FROM entrees WHERE niveau = ? AND groupe = ? ORDER BY date_ajout DESC LIMIT 0, 15') ;
								$req->execute(array($_GET['classe'], $_GET['groupe'])) ;
								
								while ($donnees = $req->fetch())
								{
									echo ('<p>L\'entree numero ' . $donnees["id"] . ' pese ' 
										.$donnees["poid"] . ' grammes et rapporte ' .$donnees["point"]. ' points.</p>');
								}
								
								$req->closeCursor() ;
							}
							else
							{
								/*Affichage du classement du niveau selectionn�*/
								$req = $this->bdd->prepare('SELECT * FROM classe WHERE niveau = ? ORDER BY total DESC');
								$req->execute(array($_GET['classe'])) ;
								
								echo ("<table> <caption><h3>Classement total :</h3></caption> <tr> <th>Classe</th> <th>Poid</th> <th>Points</th> <th>Total</th></tr>") ;
									while($donnees = $req->fetch())
									{
										echo ('<tr> <td>' . $donnees['niveau'] . '<sup>�m</sup>' . $donnees['groupe'] . '</td> 
											<td>' . $donnees['poid'] . '</td> <td>' . $donnees['point'] . '</td><td>'. $donnees['total'] . '</td>') ;
									}
								echo ("</table>") ;
								
								$req->closeCursor() ;
							}
						}
						else
						{
							/*Affichage du classement g�n�ral, par poid ou points*/
							switch($_GET['classement'])
							{
								case 1:
									echo("<table> <caption><h3>Classement total :</h3></caption>") ;
									$req = $this->bdd->query('SELECT * FROM classe ORDER BY total DESC');
									break;
								case 2:
									echo("<table> <caption><h3>Classement par points :</h3></caption>") ;
									$req = $this->bdd->query('SELECT * FROM classe ORDER BY point DESC');
									break;
								case 3:
									echo("<table> <caption><h3>Classement par poid :</h3></caption>") ;
									$req = $this->bdd->query('SELECT * FROM classe ORDER BY poid DESC');
									break;
								default:
									echo("<h2>Probleme mon gars</h2>") ;
									break;
							}
							$i = 1;
									
							echo ("<table> <tr> <th>Rang</th><th>Classe</th> <th>Poid</th> <th>Points</th> <th>Total</th></tr>") ;
							while($donnees = $req->fetch())
							{
								echo ('<tr> <td>'. $i .'<td>' . $donnees['niveau'] . '<sup>�m</sup>' . $donnees['groupe'] . '</td> 
								<td>' . $donnees['poid'] . '</td> <td>' . $donnees['point'] . '</td><td>'. $donnees['total'] . '</td>') ;
								$i ++;
							}
							echo ("</table>") ;
						}
					}
					else
					{
						echo('<h1>Never trust user input.</h1>') ;		
					}				
				
			}
			
			elseif($texte == 'CONNECTION')
			{
			?>
				<div class="element_menu">
					<h3>Se connecter</h3>
					<form action='home.php' method='post' id='formulaire_connection'>								
						<label for='login'>Pseudo :</label><input type='text' id='login' name='login' />
						<label for='passwd'>Mot de passe :</label><input type='password' id='passwd' name='passwd' />
						<br /> <br />
						<input type='submit' value='Se connecter'/>
						</form>
						<br />
				</div>
			<?php
			}
		}
	}
?>