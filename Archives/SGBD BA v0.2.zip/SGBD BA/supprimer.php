<?php 		
	session_start() ;
	require('fonction.php') ;
	
	$bdd = connection() ;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
   <head>
       <title>Bienvenue sur mon site !</title>
       <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	   <link rel="stylesheet" media="screen" type="text/css" title="Design" href="design.css" />
   </head>
   <body>

		<div class='page'>
		
			<?php
				include ("codes_communs/en_tete.php") ; 
				include ("codes_communs/menu.php") ; 
			?>
			
			<div id="corps">
				<div class='message'>
					<?php
						if (isset($_SESSION['message']))
						{
							echo $_SESSION['message'] ;
							$_SESSION['message'] = '' ;
						}
					?>
				</div>
			
				<div class="formulaire">
					<?php
						if (isset($_SESSION['login']) && isset($_SESSION['passwd']))
						{
							if($_SESSION['admin'] == 1)
							{
								$req = $bdd->query('SELECT * FROM entrees') ;
							}
							else
							{
								$req = $bdd->prepare('SELECT * FROM entrees WHERE id_ajout = ?') ;
								$req->execute(array($_SESSION['id'])) ;
							}
							echo '<fieldset><legend>Supprimer une entr�e</legend>
								<table>
									<tr>
										<th>Classe</th> 
										<th>Poids</th>
										<th>Points</th>
										<th>Supprimer</th>
									</tr>' ;
								
								while($donnees = $req->fetch())
								{
									echo '<tr>
											<td>' . $donnees['niveau'] . '<sup>�m</sup>' . $donnees['groupe'] . '</td>
											<td>' . $donnees['poid'] . '</td>
											<td>' . $donnees['point'] . '</td>
											<td><a href=\'action.php?action=supprimer&amp;id=' . $donnees['id'] . '\'><img src="images/corbeille.jpg"></a></td>
										</tr>' ;
								}
							
								
							echo '</table><br /> <br /></fieldset>' ;
							
						}
						else
						{
							header('Location: index.php') ;
						}
					?>
			</div>
		</div>
		
		<?php include("codes_communs/pied_de_page.php") ; ?>
		</div>
		
   </body>
</html>