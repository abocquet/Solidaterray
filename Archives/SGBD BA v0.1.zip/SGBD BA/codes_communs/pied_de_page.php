	<div id="pied_de_page">
		<p>Copyright "PrimProg" 2011, tous droits r�serv�s</p>
	</div>