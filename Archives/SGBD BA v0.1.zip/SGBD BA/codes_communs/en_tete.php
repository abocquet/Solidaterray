<div id="en_tete">
	<a href="index.php"><img class="imgblock" src="./images/logo.jpg" title="Acceuil" /></a>
</div>
		
		