<div id="menu">
			<div class="element_menu"> <!-- 'Acceuil' -->
				<h3><a href='index.php'>Acceuil</a></h3>
				
			</div>
			
			<div class="element_menu"> <!-- Fenetre de connection et gestion de la session -->
				<?php 
					if(!isset($_SESSION['login']) && !isset($_SESSION['passwd']))
					{
						?>
						<h3>Se connecter</h3>
						<form action='action.php' method='post'>								
							<label for='login'>Pseudo :</label><input type='text' id='login' name='login' />
							<label for='passwd'>Mot de passe :</label><input type='password' id='passwd' name='passwd' />
							<br /> <br />
							<input type='submit' value='Se connecter'/>
						</form>
						<br />

						<?php
					}
					
					else 
					{
						echo '<h3>Bonjour ' . $_SESSION['prenom'] . "</h3> 
						<a href='ajouter.php'>Ajouter une entr�e</a> <br />
						<a href='supprimer.php'>Supprimer une entr�e</a> <br />
						<a href='action.php?action=deconnecte'> Se deconnecter</a> " ;
					
					}
				?>
			</div>
			
			<div class="element_menu"> <!-- Classement -->
				<h3>Voir le classement :</h3>
				<ul>
					<li><a href='classement.php?classement=1'>Classement total</a></li>
					<li><a href='classement.php?classement=2'>Classement par points</a></li>
					<li><a href='classement.php?classement=3'>Classement par poid</a></li>
				</ul>
				
			</div>
			
			<div class="element_menu"> <!-- D�tail par classes -->
				<h3>Voir les fiches par classe :</h3>
				<ul>
					<li>
						<dl>
							<dt><a href='classement.php?classement=4&amp;classe=6'>Classement 6<sup>�me</sup></a></dt>
							<dd><a href='classement.php?classement=4&amp;classe=6&amp;groupe=1'>6<sup>�me</sup>1</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=6&amp;groupe=2'>6<sup>�me</sup>2</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=6&amp;groupe=3'>6<sup>�me</sup>3</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=6&amp;groupe=4'>6<sup>�me</sup>4</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=6&amp;groupe=5'>6<sup>�me</sup>5</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=6&amp;groupe=6'>6<sup>�me</sup>6</a><dd>
						</dl>
					</li>
					<li>
						<dl>
							<dt><a href='classement.php?classement=4&amp;classe=5em'>Classement 5<sup>�me</sup></a></dt>
							<dd><a href='classement.php?classement=4&amp;classe=5&amp;groupe=1'>5<sup>�me</sup>1</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=5&amp;groupe=2'>5<sup>�me</sup>2</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=5&amp;groupe=3'>5<sup>�me</sup>3</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=5&amp;groupe=4'>5<sup>�me</sup>4</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=5&amp;groupe=5'>5<sup>�me</sup>5</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=5&amp;groupe=6'>5<sup>�me</sup>6</a><dd>
						</dl>
					</li>
					<li>
						<dl>
							<dt><a href='classement.php?classement=4&amp;classe=4em'>Classement 4<sup>�me</sup></a></dt>
							<dd><a href='classement.php?classement=4&amp;classe=4&amp;groupe=1'>4<sup>�me</sup>1</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=4&amp;groupe=2'>4<sup>�me</sup>2</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=4&amp;groupe=3'>4<sup>�me</sup>3</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=4&amp;groupe=4'>4<sup>�me</sup>4</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=4&amp;groupe=5'>4<sup>�me</sup>5</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=4&amp;groupe=6'>4<sup>�me</sup>6</a><dd>
						</dl>
					</li>
					<li>
						<dl>
							<dt><a  href='classement.php?classement=4&amp;classe=3em'>Classement 3<sup>�me</sup></a></dt>
							<dd><a href='classement.php?classement=4&amp;classe=3&amp;groupe=1'>3<sup>�me</sup>1</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=3&amp;groupe=2'>3<sup>�me</sup>2</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=3&amp;groupe=3'>3<sup>�me</sup>3</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=3&amp;groupe=4'>3<sup>�me</sup>4</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=3&amp;groupe=5'>3<sup>�me</sup>5</a><dd>
							<dd><a href='classement.php?classement=4&amp;classe=3&amp;groupe=6'>3<sup>�me</sup>6</a><dd>
						</dl>
					</li>
				</ul>
			</div>
			
			
		</div>