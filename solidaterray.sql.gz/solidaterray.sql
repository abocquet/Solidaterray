-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 07 Septembre 2011 à 11:52
-- Version du serveur: 5.5.8
-- Version de PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `solidaterray`
--

-- --------------------------------------------------------

--
-- Structure de la table `classe`
--

CREATE TABLE IF NOT EXISTS `classe` (
  `niveau` int(11) NOT NULL COMMENT '6em, 5em, 4em, 3em',
  `groupe` int(11) NOT NULL COMMENT '6em 1, 6em 2 ect',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poid` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  `total` int(11) NOT NULL COMMENT 'poid * points',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Contenu de la table `classe`
--

INSERT INTO `classe` (`niveau`, `groupe`, `id`, `poid`, `point`, `total`) VALUES
(6, 1, 1, 12, 120, 1440),
(6, 2, 2, 20, 86, 1720),
(6, 3, 3, 554, 10000, 45),
(6, 4, 4, 0, 0, 0),
(6, 5, 5, 0, 0, 0),
(6, 6, 6, 0, 0, 0),
(5, 1, 7, 0, 0, 0),
(5, 2, 8, 0, 0, 0),
(5, 3, 9, 0, 0, 0),
(5, 4, 10, 0, 0, 0),
(5, 5, 11, 0, 0, 0),
(5, 6, 12, 0, 0, 0),
(4, 1, 13, 0, 0, 0),
(4, 2, 14, 0, 0, 0),
(4, 3, 15, 0, 0, 0),
(4, 4, 16, 0, 0, 0),
(4, 5, 17, 0, 0, 0),
(4, 6, 18, 0, 0, 0),
(3, 1, 19, 0, 0, 0),
(3, 2, 20, 0, 0, 0),
(3, 3, 21, 0, 0, 0),
(3, 4, 22, 0, 0, 0),
(3, 5, 23, 0, 0, 0),
(3, 6, 24, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `entrees`
--

CREATE TABLE IF NOT EXISTS `entrees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poid` int(11) NOT NULL COMMENT 'en grammes',
  `type` int(11) NOT NULL COMMENT 'penser a faire un tableau d''equivalence',
  `id_ajout` int(11) NOT NULL COMMENT 'id de l''utilisateur qui a fait l''ajout',
  `point` int(11) NOT NULL,
  `niveau` int(11) NOT NULL,
  `groupe` int(11) NOT NULL,
  `date_ajout` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `entrees`
--

INSERT INTO `entrees` (`id`, `poid`, `type`, `id_ajout`, `point`, `niveau`, `groupe`, `date_ajout`) VALUES
(1, 5, 2, 0, 120, 6, 1, '0000-00-00'),
(2, 12, 5, 0, 124, 6, 1, '2011-07-05');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE IF NOT EXISTS `membre` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `administrateur` tinyint(1) NOT NULL COMMENT 'booleen',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`id`, `nom`, `prenom`, `pseudo`, `pass`, `administrateur`) VALUES
(1, 'Bocquet', 'Adrien', 'alphindia', '4d10829f147c13c63c4579f5297a87efba1143a3', 1),
(2, 'Pichancourd', 'Baptiste', 'babou', '1cfd48a9a65a966defdcd720f66cd790094000c4 ', 0),
(3, 'test', 'test', 'test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3 ', 1);
